﻿(function(common) {


}(angular.module("common")))