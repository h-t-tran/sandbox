﻿(function (module) {


}(angular.module("common")));