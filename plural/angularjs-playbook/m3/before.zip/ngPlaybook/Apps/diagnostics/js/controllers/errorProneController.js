﻿(function(module) {

    var errorProneController = function () {

    };

    module.controller("errorProneController", errorProneController);

}(angular.module("diagnostics")))