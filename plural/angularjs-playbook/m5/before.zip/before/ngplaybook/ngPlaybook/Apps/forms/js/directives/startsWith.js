﻿(function (module) {

    var startsWith = function () {

        return {           
        };

    };

    //module.directive("startsWith", startsWith);

}(angular.module("forms")));
