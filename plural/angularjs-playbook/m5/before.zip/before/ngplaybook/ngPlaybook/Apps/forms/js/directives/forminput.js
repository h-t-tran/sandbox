﻿(function (module) {
   
    var forminput = function () {

        return {        
        };

    };

    //module.directive("forminput", forminput);

}(angular.module("forms")));
