﻿(function (module) {

    var username = function ($http, alerting, $q, $compile) {

        return {

        }
    };

    //module.directive("username", username);

}(angular.module("forms")));
