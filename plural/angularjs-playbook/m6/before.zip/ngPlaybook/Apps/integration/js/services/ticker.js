﻿(function (module) {

    module.factory("ticker", function () {
        
    }); 
    
}(angular.module("integration")));
