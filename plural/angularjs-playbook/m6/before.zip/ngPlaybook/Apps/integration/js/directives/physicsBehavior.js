﻿(function (module) {

    module.directive("physicsBehavior", function (Physics, world) {
        return {
           
        };
    });

}(angular.module("integration")));
