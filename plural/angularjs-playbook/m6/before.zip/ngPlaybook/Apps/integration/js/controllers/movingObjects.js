﻿(function (module) {

    var movingObjectController = function () {


    };

    module.controller("movingObjectController", movingObjectController);

}(angular.module("integration")));
