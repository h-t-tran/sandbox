﻿
(function (module) {

    module.directive("physicsBody", function (Physics, world) {
        return {
         
        };
    });

}(angular.module("integration")));
