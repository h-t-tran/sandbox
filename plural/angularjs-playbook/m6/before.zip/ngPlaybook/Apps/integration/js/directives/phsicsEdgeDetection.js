﻿(function (module) {

    module.directive("physicsEdgeDetection", function () {
        return {
            
        };
    });


}(angular.module("integration")));