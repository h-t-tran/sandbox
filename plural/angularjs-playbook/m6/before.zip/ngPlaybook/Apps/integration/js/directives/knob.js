﻿(function (module) {

    var knob = function () {

        return {
           
        };

    };

    module.directive("knob", knob);

}(angular.module("integration")));
