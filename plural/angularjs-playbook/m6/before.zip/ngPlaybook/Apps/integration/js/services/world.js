﻿(function (module) {

    module.factory("world", function () {
        
    });
   
}(angular.module("integration")));
