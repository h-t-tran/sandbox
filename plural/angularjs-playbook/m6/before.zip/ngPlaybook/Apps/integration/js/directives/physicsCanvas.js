﻿(function (module) {

    module.directive("physicsCanvas", function (Physics, world, ticker) {
        return {
           
        };
    });

}(angular.module("integration")));
