﻿
(function () {

    var app = angular.module("integration", ["common", "ngRoute", "ngAnimate", "ngMessages"]);


}());