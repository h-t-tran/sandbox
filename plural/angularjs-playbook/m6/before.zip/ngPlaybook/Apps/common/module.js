﻿(function() {

    var module = angular.module("common", ["ngAnimate"]);

}());