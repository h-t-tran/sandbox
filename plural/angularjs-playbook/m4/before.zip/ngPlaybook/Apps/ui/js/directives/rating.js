﻿(function (module) {

    var rating = function () {
        return {
            
        };
    };

    module.directive("rating", rating);

}(angular.module("ui")));