﻿(function (module) {

    var confirmPromotion = function () {
        return {};
    };

    module.factory("confirmPromotion", confirmPromotion);

}(angular.module("ui")));
