﻿var config = {
    baseUrl: "http://localhost:17648/Apps/"
};

module.exports = config;